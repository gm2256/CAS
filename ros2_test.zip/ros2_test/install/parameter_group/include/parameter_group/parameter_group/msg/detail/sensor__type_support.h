// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from parameter_group:msg/Sensor.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "parameter_group/msg/sensor.h"


#ifndef PARAMETER_GROUP__MSG__DETAIL__SENSOR__TYPE_SUPPORT_H_
#define PARAMETER_GROUP__MSG__DETAIL__SENSOR__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "parameter_group/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_parameter_group
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  parameter_group,
  msg,
  Sensor
)(void);

#ifdef __cplusplus
}
#endif

#endif  // PARAMETER_GROUP__MSG__DETAIL__SENSOR__TYPE_SUPPORT_H_
