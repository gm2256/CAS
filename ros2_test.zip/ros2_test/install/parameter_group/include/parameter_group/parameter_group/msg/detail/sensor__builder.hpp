// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from parameter_group:msg/Sensor.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "parameter_group/msg/sensor.hpp"


#ifndef PARAMETER_GROUP__MSG__DETAIL__SENSOR__BUILDER_HPP_
#define PARAMETER_GROUP__MSG__DETAIL__SENSOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "parameter_group/msg/detail/sensor__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace parameter_group
{

namespace msg
{

namespace builder
{

class Init_Sensor_sensor6
{
public:
  explicit Init_Sensor_sensor6(::parameter_group::msg::Sensor & msg)
  : msg_(msg)
  {}
  ::parameter_group::msg::Sensor sensor6(::parameter_group::msg::Sensor::_sensor6_type arg)
  {
    msg_.sensor6 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::parameter_group::msg::Sensor msg_;
};

class Init_Sensor_sensor5
{
public:
  explicit Init_Sensor_sensor5(::parameter_group::msg::Sensor & msg)
  : msg_(msg)
  {}
  Init_Sensor_sensor6 sensor5(::parameter_group::msg::Sensor::_sensor5_type arg)
  {
    msg_.sensor5 = std::move(arg);
    return Init_Sensor_sensor6(msg_);
  }

private:
  ::parameter_group::msg::Sensor msg_;
};

class Init_Sensor_sensor4
{
public:
  explicit Init_Sensor_sensor4(::parameter_group::msg::Sensor & msg)
  : msg_(msg)
  {}
  Init_Sensor_sensor5 sensor4(::parameter_group::msg::Sensor::_sensor4_type arg)
  {
    msg_.sensor4 = std::move(arg);
    return Init_Sensor_sensor5(msg_);
  }

private:
  ::parameter_group::msg::Sensor msg_;
};

class Init_Sensor_sensor3
{
public:
  explicit Init_Sensor_sensor3(::parameter_group::msg::Sensor & msg)
  : msg_(msg)
  {}
  Init_Sensor_sensor4 sensor3(::parameter_group::msg::Sensor::_sensor3_type arg)
  {
    msg_.sensor3 = std::move(arg);
    return Init_Sensor_sensor4(msg_);
  }

private:
  ::parameter_group::msg::Sensor msg_;
};

class Init_Sensor_sensor2
{
public:
  explicit Init_Sensor_sensor2(::parameter_group::msg::Sensor & msg)
  : msg_(msg)
  {}
  Init_Sensor_sensor3 sensor2(::parameter_group::msg::Sensor::_sensor2_type arg)
  {
    msg_.sensor2 = std::move(arg);
    return Init_Sensor_sensor3(msg_);
  }

private:
  ::parameter_group::msg::Sensor msg_;
};

class Init_Sensor_sensor1
{
public:
  Init_Sensor_sensor1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Sensor_sensor2 sensor1(::parameter_group::msg::Sensor::_sensor1_type arg)
  {
    msg_.sensor1 = std::move(arg);
    return Init_Sensor_sensor2(msg_);
  }

private:
  ::parameter_group::msg::Sensor msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::parameter_group::msg::Sensor>()
{
  return parameter_group::msg::builder::Init_Sensor_sensor1();
}

}  // namespace parameter_group

#endif  // PARAMETER_GROUP__MSG__DETAIL__SENSOR__BUILDER_HPP_
