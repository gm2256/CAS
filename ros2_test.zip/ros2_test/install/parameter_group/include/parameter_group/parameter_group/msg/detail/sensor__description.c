// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from parameter_group:msg/Sensor.idl
// generated code does not contain a copyright notice

#include "parameter_group/msg/detail/sensor__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_parameter_group
const rosidl_type_hash_t *
parameter_group__msg__Sensor__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x59, 0x4a, 0xfe, 0x6a, 0x89, 0x20, 0xf4, 0xb4,
      0x8d, 0x87, 0x20, 0x93, 0x6f, 0x8e, 0x77, 0x7d,
      0x73, 0x64, 0x1d, 0x7e, 0xff, 0x60, 0x88, 0xe4,
      0xd5, 0xb1, 0xb3, 0x0e, 0x4c, 0x11, 0x72, 0x22,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char parameter_group__msg__Sensor__TYPE_NAME[] = "parameter_group/msg/Sensor";

// Define type names, field names, and default values
static char parameter_group__msg__Sensor__FIELD_NAME__sensor1[] = "sensor1";
static char parameter_group__msg__Sensor__FIELD_NAME__sensor2[] = "sensor2";
static char parameter_group__msg__Sensor__FIELD_NAME__sensor3[] = "sensor3";
static char parameter_group__msg__Sensor__FIELD_NAME__sensor4[] = "sensor4";
static char parameter_group__msg__Sensor__FIELD_NAME__sensor5[] = "sensor5";
static char parameter_group__msg__Sensor__FIELD_NAME__sensor6[] = "sensor6";

static rosidl_runtime_c__type_description__Field parameter_group__msg__Sensor__FIELDS[] = {
  {
    {parameter_group__msg__Sensor__FIELD_NAME__sensor1, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {parameter_group__msg__Sensor__FIELD_NAME__sensor2, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {parameter_group__msg__Sensor__FIELD_NAME__sensor3, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {parameter_group__msg__Sensor__FIELD_NAME__sensor4, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {parameter_group__msg__Sensor__FIELD_NAME__sensor5, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {parameter_group__msg__Sensor__FIELD_NAME__sensor6, 7, 7},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
parameter_group__msg__Sensor__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {parameter_group__msg__Sensor__TYPE_NAME, 26, 26},
      {parameter_group__msg__Sensor__FIELDS, 6, 6},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32 sensor1\n"
  "float32 sensor2\n"
  "float32 sensor3\n"
  "float32 sensor4\n"
  "float32 sensor5\n"
  "float32 sensor6\n"
  "";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
parameter_group__msg__Sensor__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {parameter_group__msg__Sensor__TYPE_NAME, 26, 26},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 97, 97},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
parameter_group__msg__Sensor__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *parameter_group__msg__Sensor__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
