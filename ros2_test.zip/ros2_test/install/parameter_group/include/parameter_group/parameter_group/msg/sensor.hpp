// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PARAMETER_GROUP__MSG__SENSOR_HPP_
#define PARAMETER_GROUP__MSG__SENSOR_HPP_

#include "parameter_group/msg/detail/sensor__struct.hpp"
#include "parameter_group/msg/detail/sensor__builder.hpp"
#include "parameter_group/msg/detail/sensor__traits.hpp"
#include "parameter_group/msg/detail/sensor__type_support.hpp"

#endif  // PARAMETER_GROUP__MSG__SENSOR_HPP_
