// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from parameter_group:msg/Sensor.idl
// generated code does not contain a copyright notice

#ifndef PARAMETER_GROUP__MSG__DETAIL__SENSOR__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define PARAMETER_GROUP__MSG__DETAIL__SENSOR__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include <cstddef>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "parameter_group/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "parameter_group/msg/detail/sensor__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace parameter_group
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
cdr_serialize(
  const parameter_group::msg::Sensor & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  parameter_group::msg::Sensor & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
get_serialized_size(
  const parameter_group::msg::Sensor & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
max_serialized_size_Sensor(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
cdr_serialize_key(
  const parameter_group::msg::Sensor & ros_message,
  eprosima::fastcdr::Cdr &);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
get_serialized_size_key(
  const parameter_group::msg::Sensor & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
max_serialized_size_key_Sensor(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace parameter_group

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_parameter_group
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, parameter_group, msg, Sensor)();

#ifdef __cplusplus
}
#endif

#endif  // PARAMETER_GROUP__MSG__DETAIL__SENSOR__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
