// generated from rosidl_generator_c/resource/idl.h.em
// with input from parameter_group:msg/Sensor.idl
// generated code does not contain a copyright notice

#ifndef PARAMETER_GROUP__MSG__SENSOR_H_
#define PARAMETER_GROUP__MSG__SENSOR_H_

#include "parameter_group/msg/detail/sensor__struct.h"
#include "parameter_group/msg/detail/sensor__functions.h"
#include "parameter_group/msg/detail/sensor__type_support.h"

#endif  // PARAMETER_GROUP__MSG__SENSOR_H_
