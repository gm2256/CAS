// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from parameter_group:msg/Sensor.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "parameter_group/msg/sensor.hpp"


#ifndef PARAMETER_GROUP__MSG__DETAIL__SENSOR__TRAITS_HPP_
#define PARAMETER_GROUP__MSG__DETAIL__SENSOR__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "parameter_group/msg/detail/sensor__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace parameter_group
{

namespace msg
{

inline void to_flow_style_yaml(
  const Sensor & msg,
  std::ostream & out)
{
  out << "{";
  // member: sensor1
  {
    out << "sensor1: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor1, out);
    out << ", ";
  }

  // member: sensor2
  {
    out << "sensor2: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor2, out);
    out << ", ";
  }

  // member: sensor3
  {
    out << "sensor3: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor3, out);
    out << ", ";
  }

  // member: sensor4
  {
    out << "sensor4: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor4, out);
    out << ", ";
  }

  // member: sensor5
  {
    out << "sensor5: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor5, out);
    out << ", ";
  }

  // member: sensor6
  {
    out << "sensor6: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor6, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Sensor & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: sensor1
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor1: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor1, out);
    out << "\n";
  }

  // member: sensor2
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor2: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor2, out);
    out << "\n";
  }

  // member: sensor3
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor3: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor3, out);
    out << "\n";
  }

  // member: sensor4
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor4: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor4, out);
    out << "\n";
  }

  // member: sensor5
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor5: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor5, out);
    out << "\n";
  }

  // member: sensor6
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor6: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor6, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Sensor & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace parameter_group

namespace rosidl_generator_traits
{

[[deprecated("use parameter_group::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const parameter_group::msg::Sensor & msg,
  std::ostream & out, size_t indentation = 0)
{
  parameter_group::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use parameter_group::msg::to_yaml() instead")]]
inline std::string to_yaml(const parameter_group::msg::Sensor & msg)
{
  return parameter_group::msg::to_yaml(msg);
}

template<>
inline const char * data_type<parameter_group::msg::Sensor>()
{
  return "parameter_group::msg::Sensor";
}

template<>
inline const char * name<parameter_group::msg::Sensor>()
{
  return "parameter_group/msg/Sensor";
}

template<>
struct has_fixed_size<parameter_group::msg::Sensor>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<parameter_group::msg::Sensor>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<parameter_group::msg::Sensor>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // PARAMETER_GROUP__MSG__DETAIL__SENSOR__TRAITS_HPP_
