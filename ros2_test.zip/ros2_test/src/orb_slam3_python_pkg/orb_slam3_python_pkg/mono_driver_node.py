import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class VideoPublisher(Node):
    def __init__(self):
        super().__init__('video_publisher')
        self.publisher_ = self.create_publisher(Image, 'video_frames', 10)
        self.timer = self.create_timer(1, self.timer_callback)  # 타이머 설정 (10Hz)
        self.cap = cv2.VideoCapture(2,cv2.CAP_V4L2)  # 카메라에서 실시간 영상
        self.bridge = CvBridge()

    def timer_callback(self):
        ret, frame = self.cap.read()  # 실시간 프레임 읽기
        if ret:
            frame_resized = cv2.resize(frame, (640, 480))  # 이미지 크기 조정
            msg = self.bridge.cv2_to_imgmsg(frame_resized, encoding="bgr8")
            msg.header.stamp = self.get_clock().now().to_msg()  
            self.publisher_.publish(msg)  # ROS2 메시지로 전송

def main(args=None):
    rclpy.init(args=args)
    video_publisher = VideoPublisher()
    rclpy.spin(video_publisher)
    video_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

