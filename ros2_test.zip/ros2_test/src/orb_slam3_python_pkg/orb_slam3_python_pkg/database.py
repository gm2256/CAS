import rclpy
from rclpy.node import Node
import mysql.connector
from mysql.connector import Error
#sql-workbench 만들어서 연결 완료 !
class MyNode(Node):
    def __init__(self):
        super().__init__('my_node')
        self.get_logger().info('Initializing database connection...')
        try:
            self.query_data()
        except Exception as e:
            self.get_logger().error(f"Error during initialization: {e}")

    # 데이터베이스 연결 함수
    def connect_to_database(self):
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="gm2256",
                password="1234",
                database="cas",
                ssl_disabled=True  # SSL 연결 비활성화 시도
            )
            if conn.is_connected():
                self.get_logger().info("Successfully connected to the database")
            return conn
        except Error as e:
            self.get_logger().error(f"Error connecting to database: {e}")
            raise

    # 데이터베이스 쿼리 함수
    def query_data(self):
        conn = self.connect_to_database()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM data")  # 원하는 쿼리 실행
            rows = cursor.fetchall()
            self.get_logger().info(f"Number of records: {len(rows)}")
            for row in rows:
                self.get_logger().info(f"Record: {row}")
        except Error as e:
            self.get_logger().error(f"Error executing query: {e}")
        finally:
            conn.close()
            self.get_logger().info("Database connection closed.")

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

