import lgpio
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class SimpleSubscriber(Node):
    def __init__(self):
        super().__init__('wheel_controller')
        self.PWM = 12    
        self.PWM2 = 13  
        #왼쪽 바퀴
        self.IN1 = 23    
        self.IN2 = 24    
        #오른쪽 바퀴
        self.IN3 = 17    
        self.IN4 = 27    
        # 핀 설정 
        self.h = lgpio.gpiochip_open(0)
        #왼쪽 모터 
        lgpio.gpio_claim_output(self.h, self.PWM)
        lgpio.gpio_claim_output(self.h, self.IN1)
        lgpio.gpio_claim_output(self.h, self.IN2)
        #오른쪽 모터 
        lgpio.gpio_claim_output(self.h, self.PWM2)
        lgpio.gpio_claim_output(self.h, self.IN3)
        lgpio.gpio_claim_output(self.h, self.IN4)
        
        #센서 거리 받는 노드
        self.subscription = self.create_subscription(
            String,
            'direction',  # 구독할 토픽 이름
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

    # 주기적으로 반복    
    def listener_callback(self, msg):
        # msg 데이터가 존재하면 
        if msg :
           if msg.data =="전진":
              self.front()
              time.sleep(10)
              self.stop() 
              self.get_logger().info(f'I heard: "{msg.data}"')
           elif msg.data =="후진" :
              self.back()
              time.sleep(10)
              self.stop()
              self.get_logger().info(f'I heard: "{msg.data}"')
           elif msg.data =="왼쪽" :
              self.left()
              time.sleep(10)
              self.stop()
              self.get_logger().info(f'I heard: "{msg.data}"') 
           elif msg.data()=="오른쪽":
              self.right()
              time.sleep(10)
              self.stop()           
           #데이터는 존재하나 글자가 아닌경우 --> 숫자인경우 --> 속도로 가정 
           else:   
              self.PWM_control(int(msg.data)) 
              self.get_logger().info(f'v: "{msg.data}"') 
        else:
            self.stop()
    
    #모터 방향 설정 --> (오른쪽, 왼쪽)
    def motor_cw(self, x, y):
        lgpio.gpio_write(self.h, x, 0)
        lgpio.gpio_write(self.h, y, 1)
       

    def motor_ccw(self, x, y):
        lgpio.gpio_write(self.h, x, 1)
        lgpio.gpio_write(self.h, y, 0)
       
    
    def stop(self):
        lgpio.gpio_write(self.h, self.IN1, 0)
        lgpio.gpio_write(self.h, self.IN2, 0)
        lgpio.gpio_write(self.h, self.IN3, 0)
        lgpio.gpio_write(self.h, self.IN4, 0)
    
    #속도 조절 
    def PWM_control(self,v):
        lgpio.tx_pwm(self.h, self.PWM, 1000, v)
        lgpio.tx_pwm(self.h, self.PWM2, 1000, v)

    def PWM_50(self):
        lgpio.tx_pwm(self.h, self.PWM, 1000, 50)
        lgpio.tx_pwm(self.h, self.PWM2, 1000, 50)
    
    #방향 조절 함수 
    def left(self):
        self.motor_cw(self.IN1, self.IN2)
        self.motor_ccw(self.IN3, self.IN4)
    
    def right(self):
        self.motor_ccw(self.IN1, self.IN2)
        self.motor_cw(self.IN3, self.IN4)
    
    def front(self):
        self.motor_cw(self.IN1, self.IN2)
        self.motor_cw(self.IN3, self.IN4)

    def back(self):
        self.motor_ccw(self.IN1, self.IN2)
        self.motor_ccw(self.IN3, self.IN4)
    
    def stop(self):
        #정지
        lgpio.gpio_write(self.h, self.IN1, 0)
        lgpio.gpio_write(self.h, self.IN2, 0)
        lgpio.gpio_write(self.h, self.IN3, 0)
        lgpio.gpio_write(self.h, self.IN4, 0)

def main(args=None):
    rclpy.init(args=args)

    # 노드 생성
    simple_subscriber = SimpleSubscriber()

    try:
        # ROS2 스피닝(spinning)
        rclpy.spin(simple_subscriber)
    except KeyboardInterrupt:
        print("Ctrl+C detected! Exiting...")
    finally:
        # 종료 시, 자원 해제
        lgpio.gpiochip_close(simple_subscriber.h)
        simple_subscriber.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()


