import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class ImagePublisher(Node):
    def __init__(self):
        super().__init__('image_publisher')
        
        # 퍼블리셔 생성, 토픽 이름은 'video_frames'
        self.publisher_ = self.create_publisher(Image, 'camera', 10)
        
        # OpenCV로 웹캠 영상 캡처
        self.cap = cv2.VideoCapture(2)  # 0은 기본 웹캠을 의미
        self.br = CvBridge()

        # 0.1초마다 콜백 실행 (약 10fps)
        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        ret, frame = self.cap.read()
        if ret:
            # OpenCV 이미지를 ROS 메시지로 변환
            resized_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            image_message = self.br.cv2_to_imgmsg(resized_frame, encoding="bgr8")
            
            # 퍼블리시
            self.publisher_.publish(image_message)
            self.get_logger().info('Publishing video frame')
        
        # 웹캠 창에 영상도 표시
        cv2.imshow("Webcam Feed", resized_frame)
        
        # 'q' 키를 누르면 종료
        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.get_logger().info('Video display closed')
            self.cap.release()
            rclpy.shutdown()

def main(args=None):
    rclpy.init(args=args)
    
    image_publisher = ImagePublisher()

    rclpy.spin(image_publisher)
    
    # 종료되면 노드와 창을 정리
    image_publisher.destroy_node()
    cv2.destroyAllWindows()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
