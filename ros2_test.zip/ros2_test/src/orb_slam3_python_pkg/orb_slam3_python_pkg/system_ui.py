from parameter_group.msg import Sensor
import rclpy
from rclpy.node import Node
# 모터,센서에 사용
from std_msgs.msg import String 
#영상 수신 
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge 
#UI
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QGridLayout, QLabel, QPushButton, QLineEdit
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt
from parameter_group.msg import Sensor

class MyROSNode(Node):
    def __init__(self,label_cam = None):
        super().__init__('my_ros_node')
        # 퍼블리셔 생성, 토픽 이름은 'direction'
        self.publisher_ = self.create_publisher(String, 'direction', 1) 
        #초음파 센서 값 받기 
        self.subscriber_ = self.create_subscription(String,'sensor_data',self.sensor_callback,10) 
        #영상도 받아서 출력 msg
        self.subscriber_1 = self.create_subscription(Image,'video_frames',self.video_callback,10)  
        self.subscriber_1  # 방지: 구독자가 없는 경우 GC에 의해 수거되는 문제
        self.br = CvBridge()
        self.label_cam = label_cam
        
        #데이터 베이스 송신
    def publish_direction(self, direction):
        msg = String()
        msg.data = direction
        self.publisher_.publish(msg)
        self.get_logger().info(f"Published: '{direction}'")
    
    def sensor_callback(self,msg):
        #초음파 1,2,3,4,5,6 
        self.get_logger().info(f"Published: '{msg.data}'")
        #데이터 6개 
        self.received_data = msg.sensor
        self.received_data2 = msg.sensor2
        self.received_data3 = msg.sensor3
        self.received_data4 = msg.sensor4
        self.received_data5 = msg.sensor5
        self.received_data6 = msg.sensor6
    
    def video_callback(self,msg):
        
        current_frame = self.br.imgmsg_to_cv2(msg, "bgr8")
        
        # OpenCV 이미지를 QImage로 변환
        height, width, channel = current_frame.shape
        bytes_per_line = 3 * width
        q_img = QImage(current_frame.data, width, height, bytes_per_line, QImage.Format_BGR888)

        # QLabel에 이미지를 표시
        self.label_cam.setPixmap(QPixmap.fromImage(q_img))
        
        # 키보드 입력을 기다림 (1ms)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            self.get_logger().info('Video display closed')
            rclpy.shutdown()


class MyApp(QWidget):
    def __init__(self, ros_node):
        super().__init__()
        self.ros_node = ros_node
        self.init_ui()

    def init_ui(self):
        # 레이아웃을 변경하여 값 입력란이 잘 보이도록 함u
        layout = QVBoxLayout()
   
        # 레이블 추가 (토픽에서 받은 데이터를 표시할 레이블) 초음파 센서 
        self.label = QLabel('1:초음파값', self)
        layout.addWidget(self.label)
        
        # 레이블 추가 (토픽에서 받은 데이터를 표시할 레이블) 초음파 센서2 
        self.label2 = QLabel('2:초음파값', self)
        layout.addWidget(self.label2)       
        
        # 레이블 추가 (토픽에서 받은 데이터를 표시할 레이블) 초음파 센서3
        self.label3 = QLabel('3:초음파값', self)
        layout.addWidget(self.label3)
        # QLabel 생성 (여기에 영상이 출력됨)
        self.label_cam = QLabel(self)
        self.label_cam.setAlignment(Qt.AlignCenter)
        self.label_cam.setText("Waiting for video stream...")
        layout.addWidget(self.label_cam, alignment=Qt.AlignCenter)  

        # 레이블 추가 (토픽에서 받은 데이터를 표시할 레이블) 초음파 센서4
        self.label4 = QLabel('4:초음파값', self)
        layout.addWidget(self.label4)   

        # 레이블 추가 (토픽에서 받은 데이터를 표시할 레이블) 초음파 센서5
        self.label5= QLabel('5:초음파값', self)
        layout.addWidget(self.label5)
        
        # 레이블 추가 (토픽에서 받은 데이터를 표시할 레이블) 초음파 센서6 
        self.label6 = QLabel('6:초음파값', self)
        layout.addWidget(self.label6)    
               
        # 버튼 추가 (UI 테스트용)
        self.button = QPushButton('초음파 센서 값', self)
        self.button.clicked.connect(self.update_label)
        layout.addWidget(self.button)
        
        # QLineEdit 추가 (값 입력을 위한 입력창)
        self.input_field = QLineEdit(self)
        self.input_field.setPlaceholderText('속도 입력 (경고: 외부전원 문제가 있어 최소 60이상 설정해야 제대로 작동)')
        layout.addWidget(self.input_field)

        # 값 전송 버튼 추가
        self.button_send = QPushButton('값 전송')
        self.button_send.clicked.connect(self.on_click_send)
        layout.addWidget(self.button_send)
        
        # 그리드 레이아웃을 사용하여 방향 버튼 배치
        grid_layout = QGridLayout()

        self.button_up = QPushButton('전진')
        self.button_up.setFixedSize(100, 30)
        self.button_up.clicked.connect(self.on_click_up)
        grid_layout.addWidget(self.button_up, 0, 1)
                        
        self.button_left = QPushButton('왼쪽')
        self.button_left.setFixedSize(100, 30)
        self.button_left.clicked.connect(self.on_click_left)
        grid_layout.addWidget(self.button_left, 1, 0)

        self.button_right = QPushButton('오른쪽')
        self.button_right.setFixedSize(100, 30)
        self.button_right.clicked.connect(self.on_click_right)
        grid_layout.addWidget(self.button_right, 1, 2)

        self.button_down = QPushButton('후진')
        self.button_down.setFixedSize(100, 30)
        self.button_down.clicked.connect(self.on_click_down)
        grid_layout.addWidget(self.button_down, 2, 1)
        
        # 데이터 베이스 전송 버튼 
        #self.button_up = QPushButton('데이터 기록 ')
        #self.button_up.clicked.connect(self.on_click_up_database)
        #grid_layout.addWidget(self.button_up, 4, 1) 

        # 방향 버튼 레이아웃을 추가
        layout.addLayout(grid_layout)

        self.setLayout(layout)
        self.setWindowTitle('ROS2 PyQt5 Node Example')

        # 창의 초기 크기 설정
        self.setGeometry(100, 100, 500, 500)  # (x, y, width, height)
        self.show()


    # 버튼 클릭 시 입력한 값 퍼블리시
    def on_click_send(self):
        input_value = self.input_field.text()  # 입력한 값 가져오기
        if input_value:
            self.ros_node.publish_direction(input_value)
        else:
            self.ros_node.get_logger().info('값을 입력하세요!')
    
    def update_label(self):
        # ROS2 노드에서 수신한 데이터를 레이블에 업데이트
        if self.ros_node.received_data is not None:
            self.label.setText(f"토픽 값: {self.ros_node.received_data}")
            self.label2.setText(f"토픽 값: {self.ros_node.received_data2}")
            self.label3.setText(f"토픽 값: {self.ros_node.received_data3}")
            self.label4.setText(f"토픽 값: {self.ros_node.received_data4}")
            self.label5.setText(f"토픽 값: {self.ros_node.received_data5}")
            self.label6.setText(f"토픽 값: {self.ros_node.received_data6}")
        else:
            self.label.setText("토픽 값: 없음")

    # 방향 버튼 클릭 시 각각 방향 퍼블리시
    def on_click_up(self):
        self.ros_node.publish_direction('전진')

    def on_click_down(self):
        self.ros_node.publish_direction('후진')

    def on_click_left(self):
        self.ros_node.publish_direction('왼쪽')

    def on_click_right(self):
        self.ros_node.publish_direction('오른쪽')


def main(args=None):
    # ROS2 초기화
    rclpy.init(args=args)

    # ROS2 노드 생성
    ros_node = MyROSNode(label_cam=None)

    # PyQt5 앱 생성
    app = QApplication(sys.argv)
    my_app = MyApp(ros_node)
    # QLabel 연결 이후에 MyROSNode의 label_cam 설정
    ros_node.label_cam = my_app.label_cam
    # 타이머로 ROS 스핀 통합
    timer = QTimer()
    timer.timeout.connect(lambda: rclpy.spin_once(ros_node, timeout_sec=0))
    timer.start(100)  # 100ms마다 ROS 콜백을 확인

    # PyQt5 이벤트 루프 실행
    sys.exit(app.exec_())

    # ROS2 종료
    rclpy.shutdown()

if __name__ == '__main__':
    main()






